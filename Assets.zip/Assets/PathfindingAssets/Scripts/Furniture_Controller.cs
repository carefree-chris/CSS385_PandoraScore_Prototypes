﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Furniture_Controller : MonoBehaviour {

    private bool isEmpty = true;

	public bool GetIsEmpty()
    {
        return isEmpty;
    }
}
